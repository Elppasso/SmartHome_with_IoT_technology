"""
Скрипт для дебагу різних типів сенсорів
Працює ТІЛЬКИ з сенсорами, пристрої яких УВІМКНЕНО (status = 1)
"""

from database import SmartHomeDB
import random
import time
import math

def print_section(title):
    print("\n" + "=" * 50)
    print(f" {title}")
    print("=" * 50)

def get_all_sensors(db):
    query = """
    SELECT 
        S.id_sensor,
        S.type,
        D.name as device_name,
        R.name as room_name,
        D.status as device_status
    FROM Sensor S
    JOIN Device D ON S.id_device = D.id_device
    JOIN Room R ON D.id_room = R.id_room
    WHERE D.status = 1
    """
    return db.execute_query(query)

def add_sensor_reading(db, sensor_id, value):
    query = f"INSERT INTO SensorData (id_sensor, value, created_at) VALUES ({sensor_id}, {value}, GETDATE())"
    return db.execute_non_query(query)

def get_sensor_status(db, sensor_id):
    query = f"""
    SELECT D.status 
    FROM Sensor S
    JOIN Device D ON S.id_device = D.id_device
    WHERE S.id_sensor = {sensor_id}
    """
    result = db.execute_query(query)
    return result and len(result) > 0 and result[0].get('status') == 1

# Генератори
def generate_temperature(): return round(random.uniform(18.0, 26.0), 1)
def generate_humidity():    return round(random.uniform(30.0, 70.0), 1)
def generate_motion():      return random.choice([0, 1])
def generate_waterleak():   return random.choice([0, 0, 0, 1])
def generate_power():       return round(random.uniform(50, 500), 1)
def generate_contact():     return random.choice([0, 1])
def generate_light():       return round(random.uniform(0, 1000), 1)
def generate_airquality():  return round(random.uniform(300, 2000), 1)

# Допоміжні
def get_name(sensor_type):
    names = {
        'Temperature': 'температури', 'Humidity': 'вологості', 'Motion': 'руху',
        'WaterLeak': 'витоку води', 'PowerMeter': 'енергії', 'Contact': 'контакту',
        'Light': 'освітлення', 'AirQuality': 'якості повітря'
    }
    return names.get(sensor_type, 'сенсора')

def get_unit(sensor_type):
    units = {
        'Temperature': '°C', 'Humidity': '%', 'Motion': '',
        'WaterLeak': '', 'PowerMeter': 'W', 'Contact': '',
        'Light': 'lux', 'AirQuality': 'ppm'
    }
    return units.get(sensor_type, '')

# Симуляції (без емодзі)
def smooth_value_change(db, sensor_id, sensor_type, start_val, end_val, duration_seconds=30, steps_per_second=2):
    if not get_sensor_status(db, sensor_id):
        print("[X] Неможливо виконати: пристрій вимкнено!")
        return
    total_steps = duration_seconds * steps_per_second
    step_size = (end_val - start_val) / total_steps
    unit = get_unit(sensor_type)
    print(f"\n[CHANGE] Плавна зміна {get_name(sensor_type)}: {start_val}{unit} -> {end_val}{unit}")
    current_val = start_val
    for step in range(total_steps + 1):
        current_val = start_val + step * step_size
        add_sensor_reading(db, sensor_id, round(current_val, 2))
        progress = step / total_steps * 100
        bar = '#' * int(30 * step / total_steps) + '-' * (30 - int(30 * step / total_steps))
        print(f"\r   Прогрес: [{bar}] {progress:.1f}% | {round(current_val, 2)}{unit}", end="")
        time.sleep(1 / steps_per_second)
    print()

def sine_wave_simulation(db, sensor_id, sensor_type, center_val, amplitude, period_seconds=30, duration_seconds=120):
    if not get_sensor_status(db, sensor_id):
        print("[X] Неможливо виконати: пристрій вимкнено!")
        return
    steps = duration_seconds * 5
    unit = get_unit(sensor_type)
    start_time = time.time()
    for i in range(steps):
        elapsed = time.time() - start_time
        if elapsed > duration_seconds:
            break
        val = center_val + amplitude * math.sin(2 * math.pi * elapsed / period_seconds)
        add_sensor_reading(db, sensor_id, round(val, 2))
        progress = elapsed / duration_seconds * 100
        bar = '#' * int(30 * elapsed / duration_seconds) + '-' * (30 - int(30 * elapsed / duration_seconds))
        print(f"\r   Прогрес: [{bar}] {progress:.1f}% | {round(val, 2)}{unit}", end="")
        time.sleep(0.2)
    print()

def random_readings(db, sensor_id, sensor_type, count=10):
    if not get_sensor_status(db, sensor_id):
        print("[X] Неможливо виконати: пристрій вимкнено!")
        return
    unit = get_unit(sensor_type)
    print(f"\n[RANDOM] {count} випадкових показань {get_name(sensor_type)}:")
    for i in range(count):
        if sensor_type == 'Temperature':
            val = generate_temperature()
        elif sensor_type == 'Humidity':
            val = generate_humidity()
        elif sensor_type == 'Motion':
            val = generate_motion()
        elif sensor_type == 'WaterLeak':
            val = generate_waterleak()
        elif sensor_type == 'PowerMeter':
            val = generate_power()
        elif sensor_type == 'Contact':
            val = generate_contact()
        elif sensor_type == 'Light':
            val = generate_light()
        elif sensor_type == 'AirQuality':
            val = generate_airquality()
        else:
            val = random.uniform(0, 100)
        add_sensor_reading(db, sensor_id, round(val, 2))
        print(f"   {i+1}. {round(val,2)}{unit}")
        time.sleep(0.2)
    print("[OK] Готово!")

def interactive_simulation(db, sensor_id, sensor_type):
    if not get_sensor_status(db, sensor_id):
        print("[X] Неможливо виконати: пристрій вимкнено!")
        return
    unit = get_unit(sensor_type)
    query = f"SELECT TOP 1 value FROM SensorData WHERE id_sensor = {sensor_id} ORDER BY created_at DESC"
    last = db.execute_query(query)
    current_val = last[0]['value'] if last else 0
    print(f"\n[INTERACTIVE] Інтерактивна симуляція {get_name(sensor_type)} (поточне: {current_val}{unit})")
    print("   W/S – зміна, R – випадкове, Q – вихід")
    try:
        while True:
            print(f"\r   [NOW] {current_val}{unit}    ", end="")
            import msvcrt
            if msvcrt.kbhit():
                key = msvcrt.getch().decode('utf-8').lower()
                if key in ['w', 'в', 'і']:
                    if sensor_type in ['Motion', 'WaterLeak', 'Contact']:
                        current_val = 1
                    else:
                        current_val += 1
                    add_sensor_reading(db, sensor_id, round(current_val, 2))
                    print(f"\n   [UP] -> {current_val}{unit}")
                elif key in ['s', 'ы', 'і']:
                    if sensor_type in ['Motion', 'WaterLeak', 'Contact']:
                        current_val = 0
                    else:
                        current_val = max(0, current_val - 1)
                    add_sensor_reading(db, sensor_id, round(current_val, 2))
                    print(f"\n   [DOWN] -> {current_val}{unit}")
                elif key == 'r':
                    if sensor_type == 'Temperature':
                        current_val = generate_temperature()
                    elif sensor_type == 'Humidity':
                        current_val = generate_humidity()
                    elif sensor_type == 'Motion':
                        current_val = generate_motion()
                    elif sensor_type == 'WaterLeak':
                        current_val = generate_waterleak()
                    elif sensor_type == 'PowerMeter':
                        current_val = generate_power()
                    elif sensor_type == 'Contact':
                        current_val = generate_contact()
                    elif sensor_type == 'Light':
                        current_val = generate_light()
                    elif sensor_type == 'AirQuality':
                        current_val = generate_airquality()
                    else:
                        current_val = random.uniform(0, 100)
                    add_sensor_reading(db, sensor_id, round(current_val, 2))
                    print(f"\n   [RAND] -> {current_val}{unit}")
                elif key == 'q':
                    break
            time.sleep(0.2)
    except KeyboardInterrupt:
        print("\n[STOP] Зупинено")

def main():
    print_section("ДЕБАГ СЕНСОРІВ (ТІЛЬКИ УВІМКНЕНІ ПРИСТРОЇ)")
    db = SmartHomeDB()

    # Перевірка підключення
    try:
        if not db.execute_query("SELECT 1"):
            print("[X] Немає підключення до БД")
            return
    except:
        print("[X] Помилка підключення")
        return
    print("[OK] Підключення успішне")

    all_sensors = get_all_sensors(db)
    if not all_sensors:
        print("[X] Немає жодного сенсора на увімкнених пристроях!")
        return

    # Групуємо за типом
    sensors_by_type = {}
    for s in all_sensors:
        t = s['type']
        sensors_by_type.setdefault(t, []).append(s)

    print("\nДоступні типи сенсорів (тільки увімкнені):")
    type_list = list(sensors_by_type.keys())
    for i, t in enumerate(type_list, 1):
        print(f"   {i}. {t} ({len(sensors_by_type[t])} шт.)")

    choice = int(input(f"\nВиберіть тип (1-{len(type_list)}): "))
    selected_type = type_list[choice - 1]
    sensors = sensors_by_type[selected_type]

    print(f"\nСенсори типу '{selected_type}':")
    for i, s in enumerate(sensors, 1):
        print(f"   {i}. {s['room_name']} - {s['device_name']} (ID: {s['id_sensor']})")

    choice = int(input(f"\nВиберіть номер сенсора (1-{len(sensors)}): "))
    selected_sensor = sensors[choice - 1]
    sensor_id = selected_sensor['id_sensor']
    sensor_type = selected_sensor['type']

    print_section(f"Обрано: {sensor_type} - {selected_sensor['device_name']} ({selected_sensor['room_name']})")

    while True:
        print("\n" + "-" * 50)
        print(f"МЕНЮ ДЛЯ {sensor_type}")
        print("-" * 50)
        print("1. Додати одне показання")
        print("2. Плавне підвищення")
        print("3. Плавне зниження")
        print("4. Синусоїда")
        print("5. 10 випадкових")
        print("6. Інтерактивна (W/S)")
        print("7. Швидке тестування (5 значень)")
        print("0. Вихід")

        choice = input("\nВаш вибір: ").strip()
        if choice == "0":
            break
        elif choice == "1":
            try:
                val = float(input(f"Значення ({get_unit(sensor_type)}): "))
                if add_sensor_reading(db, sensor_id, val):
                    print("[OK] Додано")
                else:
                    print("[X] Помилка")
            except:
                print("[X] Невірне число")
        elif choice == "2":
            try:
                start = float(input(f"Початкове ({get_unit(sensor_type)}): "))
                end = float(input(f"Кінцеве ({get_unit(sensor_type)}): "))
                dur = int(input("Тривалість (сек, 30): ") or 30)
                smooth_value_change(db, sensor_id, sensor_type, start, end, dur)
            except:
                print("[X] Помилка вводу")
        elif choice == "3":
            try:
                start = float(input(f"Початкове ({get_unit(sensor_type)}): "))
                end = float(input(f"Кінцеве ({get_unit(sensor_type)}): "))
                dur = int(input("Тривалість (сек, 30): ") or 30)
                smooth_value_change(db, sensor_id, sensor_type, start, end, dur)
            except:
                print("[X] Помилка вводу")
        elif choice == "4":
            try:
                center = float(input(f"Центр ({get_unit(sensor_type)}): "))
                amp = float(input(f"Амплітуда ({get_unit(sensor_type)}): "))
                period = int(input("Період (сек, 30): ") or 30)
                dur = int(input("Тривалість (сек, 120): ") or 120)
                sine_wave_simulation(db, sensor_id, sensor_type, center, amp, period, dur)
            except:
                print("[X] Помилка вводу")
        elif choice == "5":
            random_readings(db, sensor_id, sensor_type, 10)
        elif choice == "6":
            interactive_simulation(db, sensor_id, sensor_type)
        elif choice == "7":
            print("\n[FAST] Швидке тестування (5 значень):")
            for _ in range(5):
                if sensor_type == 'Temperature':
                    val = generate_temperature()
                elif sensor_type == 'Humidity':
                    val = generate_humidity()
                elif sensor_type == 'Motion':
                    val = generate_motion()
                elif sensor_type == 'WaterLeak':
                    val = generate_waterleak()
                elif sensor_type == 'PowerMeter':
                    val = generate_power()
                elif sensor_type == 'Contact':
                    val = generate_contact()
                elif sensor_type == 'Light':
                    val = generate_light()
                elif sensor_type == 'AirQuality':
                    val = generate_airquality()
                else:
                    val = random.uniform(0, 100)
                add_sensor_reading(db, sensor_id, round(val, 2))
                print(f"   {round(val,2)}{get_unit(sensor_type)}")
                time.sleep(0.2)
            print("[OK] Готово")
        else:
            print("[X] Невірний вибір")

if __name__ == "__main__":
    main()